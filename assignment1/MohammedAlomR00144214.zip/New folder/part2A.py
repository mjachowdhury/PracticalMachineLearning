# -*- coding: utf-8 -*-
"""
Created on Sat Nov 14 23:21:29 2020

@author: Mohammed Alom Student No - R00144214
"""

import numpy as np 
import matplotlib.pyplot as plt 
from mpl_toolkits.mplot3d import Axes3D
import random
import time 
import csv
  

# Instesd of looping fixed number of time user can input number of iteration.
number_of_iteratons = int(input('HOW MANY ITERATION YOU WANT? :'))
number_of_clusters = int(input('HOW MANY CLUSTER/CENTROIDS YOU WANT? :'))

#data directory. please changed as necessary     
clustering_data_dir = "E:/MSc/ML/Assignment1/assignmentOne/data/clustering/"

def loadDataset(fileName):
    with open(fileName,"r") as csvfile: 
        lines = csv.reader(csvfile)
        data = list(lines)
        return data 

cluster_data = loadDataset(clustering_data_dir + "data.csv")
data = np.array(cluster_data, dtype = float)

# Shuffle the cluster data
np.random.shuffle(data) 

#print("\n-------- 3D VIEW OF THE DATA POSITION -------------")
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')
ax.scatter(data[:,0], data[:,1], data[:,2], s= 0.5)
plt.title("DATA POSITION AFTER INITIALIZATION")
plt.show()

# Set the random seed for reproducibility 
random.seed(0)

def generate_centroids(data, number_of_clusters):
    centroids = data[random.sample(range(data.shape[0]), number_of_clusters)]
    return centroids
 
def assign_centroids(data):
    assigned_centroids = np.zeros(len(data), dtype = np.int32)
    return assigned_centroids

centroids = generate_centroids(data, number_of_clusters)    
assigned_centroids = assign_centroids(data)  
  
def move_centroids(x, centroids):    
    # calling calculate distance function to get hte distance from data points. 
    distance = calculate_euclidean_distance(x, centroids)
    # Getting the index of the centroids with the closest distance to the data point 
    closest_centroid_index =  np.argmin(distance)   
    return closest_centroid_index

def calculate_euclidean_distance(x, centroids):
    #calculating the E distance formula
    distance = np.sqrt(np.sum((x - centroids)**2, axis=1))
    return distance

#sum_of_squared_errors
def calculate_cost(data, centroids, assigned_centroids):
    sum_squared_errors = 0    
    # Compute cost    
    sum_squared_errors = calculate_euclidean_distance(data, centroids[assigned_centroids]).sum() / len(data)    
    return sum_squared_errors

# List to store sum Of Square Errors for each iteration 
sumOfSquareError_list =[] 
#Starting iteration
iteration_start_time = time.time()

def restart_KMeans():
    # Loop over number of iterations
    for n in range(number_of_iteratons):    
        # Loop over each cluster data point
        for i in range(len(data)):
            x = data[i]            
            x = x[None, :]             
            # Geting the nearest centroid/cluster
            closest_centroid = move_centroids(x, centroids)          
            # Assigning the centroid/cluster to the data point.
            assigned_centroids[i] = closest_centroid       
        # Loop over again with centroids and calculate the new ones.
        for c in range(len(centroids)):
            # Geting all the data points belonging to a specific clusters
            cluster_data = data[assigned_centroids == c]            
            # calculating the average of each cluster members to compute the new centroid/cluster
            new_centroid = cluster_data.mean(axis = 0)            
            # assigning the new centroid/cluster
            centroids[c] = new_centroid        
        # Calculating the SSE for the per iterations
        sum_squared_errors = calculate_cost(data, centroids, assigned_centroids)
        sumOfSquareError_list.append(sum_squared_errors)

#Calling the function   
restart_KMeans()
#End iteration
iteration_stop_time = time.time()

#print("\n---------- 3D VIEW OF THE DATA AFTER ITERATIONS ----------")
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
for c in range(len(centroids)):
        cluster_members = [data[i] for i in range(len(data)) if assigned_centroids[i] == c]    
        cluster_members = np.array(cluster_members)       
        ax.scatter(cluster_members[:,0], cluster_members[:,1], cluster_members[:,2], s= 0.5)
plt.title("DATA POSITION AFTER ITERATIONS")
plt.show()


#print("\n--------------- ELBOW PLOT ------------------------")
plt.figure()
plt.xlabel("NUMBER OF ITERATIONS")
plt.ylabel("SUM OF SQUARED ERRORS")
plt.title("ELBOW PLOT")
plt.plot(range(len(sumOfSquareError_list)), sumOfSquareError_list)
plt.show()

print("TIME TOOK PER ITERATION {:.4f} Sec".format((iteration_stop_time - iteration_start_time)/ number_of_iteratons))
print("NUMBER OF ITERATION WAS : ", number_of_iteratons)
print("NUMBER OF CULTER/CENTROIDS WAS : ", number_of_clusters)
 