# -*- coding: utf-8 -*-
"""
Created on Tue Nov 10 00:41:04 2020

@author: Mohammed Alom. Student No - R00144214
"""


import numpy as np
from part1A import calculate_distances, loadDataset

#Please change the dir as required
regression_data_dir = "E:/MSc/ML/Assignment1/assignmentOne/data/regression/"

def calculate_manhattan_distances(trainData, testData):
    """
    This function calculates manhattan distance between test instance and training instances.
    """
    # manhattan distance formula
    result = np.abs(testData - trainData[:])   
    distance = np.sum(result[:, :], axis=1)  
    #Sorting the distance array
    sorted_Indices_Array = np.argsort(distance)
    #return the result ed distance and sorted indices array
    return distance, sorted_Indices_Array

def calculate_minkowski_distances(trainData, testData):
    """
    This function calculates minkowski distance between test instance and training instances.
    """
    # minkowski distance formula
    result = np.abs(testData - trainData[:]) ** 2   
    distance = np.power(np.sum(result[:, :], axis=1), 2)   
    #sorting the distance array
    sorted_Indices_Array = np.argsort(distance)  
    #return the result ed distance and sorted indices array
    return distance, sorted_Indices_Array

def calculate_distance_knn(minimum_distance_row_indexes, distance, trainingData, new_different_classes, n):
    """
    This function will calculate a distance-knn based on the selected training rows using value of k.
    step 1 - will get the lowest distance row indexes from the training data as a list.
    step 2 - finding the lowest k indexes from the euclidean distance array.
    step 3 - Normlize the distance
    step 4 - calculating the final value for each class
    step 5 - adding those value to the list.
    step 6 - return the predicted result maximum occurance value from the function.
    """
    #  getting the lowest index data from the training data set
    number_of_rows_required = trainingData[np.array(minimum_distance_row_indexes)]
    #  finding the lowest k indexes from the euclidean distance array. 
    required_euclideand_array = distance[np.array(minimum_distance_row_indexes)]
    #  normalising the distances
    normalised_distance = 1 / (required_euclideand_array ** n)
    new_list = []
    for row_class in new_different_classes:
        #  calculating knn value for each class
        final_output = np.sum(normalised_distance * np.where(number_of_rows_required[:, -1] == row_class, 1, 0))
        new_list.append(final_output)
    #  return the predicted result maximum occurance value from the function.
    return new_different_classes[new_list.index(max(new_list))]
    
def compare_other_techniques(k_value, n, trainingData, testData, new_different_classes, distance_type='euclidean'):
    """
    This is the main driving function which takes in all the training and test data and calculates accuracy based on the
    value of k provided. here k_value is the different values and n is the different power value of hte distance formula.
    """
    # loop over each value in k_values to find the different accuracies for different 'k' value
    for k in k_value:
        accuracy_list = []
        # loop over each instance of test dataset
        for row in testData:
            if distance_type == 'manhattan':
                distance, sorted_Indices_Array = calculate_manhattan_distances(trainingData[:, 0:20], row[:20])
            elif distance_type == 'minkowski':
                distance, sorted_Indices_Array = calculate_minkowski_distances(trainingData[:, 0:20], row[:20])
            else:
                distance, sorted_Indices_Array = calculate_distances(trainingData[:, 0:20], row[:20])
            #getting the minimum distance entries
            minimum_distance_row_indexes = sorted_Indices_Array[0:k]   
            #  calculating the euclidean distances calling the calculate_distance_knn function
            max_element = calculate_distance_knn(minimum_distance_row_indexes, distance, trainingData, new_different_classes, n)
            #adding to the accuracy list
            accuracy_list.append(int(row[-1]) == max_element)
        accuracy = accuracy_list.count(True) / len(accuracy_list) * 100        
        print(f'k-VALUE = {k}, ACCURACY OF THE MODEL = {round(accuracy, 4)}% , DISTANCE METHOD ={distance_type.capitalize()}\n ')


    
def get_regression_value(trainingData, minimum_distance_row_indexes, distances):
    """
    This function return regression value for each test instance based on the 
    euclidean distances between training data and each test data row instance.
    step 1 - first getting hte smallest distance to k indexes
    step 2 - getting the number of rows from the trainin dataset from the k_indexes
    step 3 - getting the distance from the k_indexes by ED formula
    step 4 - computing numerator value
    step 5 - computing denominator value
    step 6 - computing actual regression value
    step 7 - return the regression value
    """
    k_indexes = np.array(minimum_distance_row_indexes)   
    required_rows = trainingData[k_indexes] 
    required_ed_array = distances[k_indexes]
    numerator_req = np.sum(((1 / required_ed_array) ** 2) * required_rows[:, -1])   
    sum_inversion_ed = np.sum(1 / (required_ed_array ** 2))   
    regression_value = numerator_req / sum_inversion_ed   
    return regression_value

    
def supervised_wraper_method(k_value, trainingData, test_data_csv):
    """
    This is the main driving function which takes in all the training and test data and 
    calculates accuracy based on the value of k provided.
    step 1 - Initilizing r square value to 0
    step 2 - loop over each value in k_value to get the difference accuracies fro different k
    step 3 - initializing tota sum to 0
    step 4 - initializing sum of residuals to 0
    step 5 - calculating the y axis value
    step 6 - loop over on each test data instance
    step 7 - calculating the ED with trainin and test data instance
    step 8 - getting lowest row indexes
    step 9 - getting regression value on each test instance
    step 10 - getting sum of residuals 
    step 11 - getting total sum value
    step 12 - computing r square 
    step 13 - return to r square value
    """
    r_square_value = 0
    for k in k_value:
        total_sum = 0
        sum_of_residuals = 0
        y_axis = np.mean(test_data_csv[:, -1])
        for row in test_data_csv:
            distances, indices_np_array = calculate_distances(trainingData[:, 0:-1], row[:-1])
            min_distance_row_index = indices_np_array[0:k]
            regression_value = get_regression_value(trainingData, min_distance_row_index, distances)
            sum_of_residuals += (regression_value - row[-1]) ** 2
            total_sum += (y_axis - row[-1]) ** 2
        r_square_value = 1 - (sum_of_residuals / total_sum)
        print(f'k VALUE = {k}, ACCURACY OF THE MODEL WITH THE WRAPER METHOD = {r_square_value}')
    return r_square_value

if __name__ == '__main__':  
    trainData = loadDataset(regression_data_dir + "trainingData.csv") 
    trainData = np.array(trainData, dtype=float)    
    testData = loadDataset(regression_data_dir + "testData.csv") 
    testData = np.array(testData, dtype=float)  
    # unique class list which will be used if k > 1
    new_different_classes = [1, 2, 3]
    #  single value of k.
    k_value = [10]
    n = 2
    print("\n=================== DIFFERENT TECHNIQUES COMPARE =================\n")
    compare_other_techniques(k_value, n, trainData, testData, new_different_classes, 'euclidean')
    compare_other_techniques(k_value, n, trainData, testData, new_different_classes, 'manhattan')
    compare_other_techniques(k_value, n, trainData, testData, new_different_classes, 'minkowski')
    
    
    print("\n================ SUPERVISED WRAPER METHOD =====================\n")
    feature_selection = True
    accuracies = []
    k_value = [10]
    best_r_square_index = 0
    #calling wrapper method function
    best_r_square = supervised_wraper_method(k_value, trainData, testData)
    if feature_selection:
        for index in range(12):
            print(index + 1)
            indexes = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10,11,12]
            # removing feature from the above indexes list after each itertion
            indexes.remove(index)
            #  getting the subset of the features
            new_training_data_csv = trainData[:, indexes]
            new_test_data_csv = testData[:, indexes]
            #  getting the r squared value
            r_square_value = supervised_wraper_method(k_value, new_training_data_csv, new_test_data_csv)
            # updating the value
            if r_square_value > best_r_square:
                best_r_square = r_square_value
                best_r_square_index = index + 1
        print(f'WE CAN OBSERVED BY REMOVING DIFFERENT FEATURES {best_r_square_index} (COLUMN {best_r_square_index}) '
              f'WE GOT THE BEST ACCURACY.')
