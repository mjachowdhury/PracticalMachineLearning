# -*- coding: utf-8 -*-
"""
Created on Tue Nov 10 00:41:04 2020

@author: Mohammed Alom. Student No - R00144214
"""

import numpy as np
import csv
import matplotlib.pyplot as plt

#Please change as required
regression_data_dir = "E:/MSc/ML/Assignment1/assignmentOne/data/regression/"

def loadDataset(fileName):
    """
    The function will load the dataset from the regression directory.
    Loading the dataset from the regression directory.
    opening the csv file as a read mode and returning the data as a list.
    """  
    with open(fileName,"r") as csvfile: 
        lines = csv.reader(csvfile)
        data = list(lines)
        return data 

def calculate_distances(trainData, testData):
    """
    This function will use Euclidean distance formula.
    Step 1 - It will accept as an argument 1 2D array and 1 single 1D NumPy 
    array and the result will store in a new varialbe which is distance.
    Step 2 - The result will pass to the np.argsort method to sort the distance
    array and the result will store a new varaible which is sorted_Indices_Array.
    Step 3 - Finally the function will return distance and sorted_Indices_Array. 
    """
    #Euclidean distance formula
    distance = np.sqrt(np.sum((trainData - testData)**2, axis=1))
    #Sorting the distance array
    sorted_Indices_Array = np.argsort(distance) 
    return distance, sorted_Indices_Array 

def predict(trainData, testData, k):
    """
    The below function will calculate the predicted regression value.
    Step 1 - The function will accept as an argument a NumPy 2D array which is
    all the features of the training data and a single 1D NumPy array query instance.
    Step 2 – slicing the both 2D and 1D NumPy array and getting only the features data.
    Step 3 – calling the Euclidean function to calculate the distance and 
    indices and store the result into A new variable.
    Step 4 – creating a new list which will store the nearest neighbours.
    Step 5 – adding to the list all the nearest neighbours.
    Step 6 – creating the two new variables as numerator and denominator
    Step 7 – then converting the list to the NumPy array
    Step 8 – calculating the numerator and the denominator value then dividing
    numerator and Denominator and the result will store in a new variable.
    Step 9 – Finally function will return the result of the predicted regression value.
    """
    #Getting the first 12 features coloums
    slice_test_data = testData[:-1] 
    slice_train_data = trainData[:, :-1]
    #Calling distance function
    distance, indices = calculate_distances(slice_train_data, slice_test_data)     
    #Will store k nearest neighbour 
    nearest_neighbours = [] 
    #Adding to the list    
    for j in range(k):
        nearest_neighbours.append(trainData[indices[j]])         
    numerator = 0 
    denominator = 0
    #Converting list to array    
    nearest_neighbours = np.array(nearest_neighbours)     
    for i in range(k):
        #compute numerator
        numerator += (1/(distance[indices[i]]**2)) * (nearest_neighbours[i,-1])
        #compute denomitor        
        denominator += 1/(distance[indices[i]]**2)
    result = numerator/denominator     
    return result 

def calculate_r2(testData, prediction_value):
    """
    The function will calculate the R2 value for the k-NN model. 
    Step 1 – The function will accept  the two NumPy array as an argument. 
    The first one is to contain the target regression value for all the test 
    instance and second array will contain the dicted regression values.
    Step 2 – Initializing two variables one for the total_sum_of_square and othe one 
            	sum_of_squared_residuals.
    Step 3 – Calculating the mean regression value for the test dataset.
    Step 4 – Getting the R2 value
    Step 5 – Finally returning the R2 value.
    """        
    total_sum_of_squares = 0 
    sum_of_squared_residuals = 0 
    mean = 0
    #Compute the mean from test data set
    mean = np.mean(testData[:,-1]) 
    for i in range(len(testData)):
        #Adding total sum of squared values
        total_sum_of_squares += (testData[i,-1] - mean)**2
        #Adding total sum of squared residuals
        sum_of_squared_residuals += (prediction_value[i] - testData[i,-1])**2
    #Computing R2 
    R2 = (1 - (sum_of_squared_residuals/total_sum_of_squares)) 
    return round(R2, 4) 

def main():
    """
    Step 1 - Loading the training and test data and converting both to NumPy array.
    Step 2 - Creating two list variables to store one for the k value and the 
    other one for the value of accuracy of k.
    Step 3 - Adding the k value to the list.
    Step 4 - Creating another list variable to store the model prediction.
    Step 5 - Calling the prediction function to get the regression value for 
    each instance and storing the result in a new variable. 
    Step 6 - Adding the result to the prediction list. 
    Step 7 - Representing the result to the graph.
    """    
    trainData = loadDataset(regression_data_dir + "trainingData.csv") 
    trainData = np.array(trainData, dtype=float)    
    testData = loadDataset(regression_data_dir + "testData.csv") 
    testData = np.array(testData, dtype=float)
    #Change as required to get the optimul value     
    k = 3 
    k_value_list = [] 
    accuracy_of_kValue = []    
    for k in range(1, 20):
        k_value_list.append(k)        
        predictions_of_the_model = []     
        for x in range(len(testData)):
            #Calling the predict function
            result = predict(trainData, testData[x], k)
            predictions_of_the_model.append(result) 
            print('PREDICTED VALUE = ' + repr(result) + ', ACTUAL VALUE = ' + repr(testData[x][-1]))
        #CAlling the calculating_r2 function
        R2_Value = calculate_r2(testData, predictions_of_the_model)        
        #print('ACCURACY OF THE MODEL- R^2 VALUE : ' + repr(R2_Value))         
        accuracy_of_kValue.append(R2_Value)         
    print('\nACCURACY OF THE MODEL- R SQUARE VALUE : ' + repr(R2_Value)) 
    maximum_accuracy_model = max(accuracy_of_kValue) 
    print('MAXIMUM ACCURACY OF THE MODEL :', maximum_accuracy_model)   
    # For ploting the k value
    maximum_value_of_k =  k_value_list[accuracy_of_kValue.index(maximum_accuracy_model)] 
    label1 = "MAXIMUM ACCURACY :",maximum_accuracy_model, "AT k :", maximum_value_of_k 
    plt.plot(k_value_list, accuracy_of_kValue, label=label1) 
    plt.xlabel('NUMBER OF NEAREST NEIGHBOURS') 
    plt.ylabel('R SQUARE VALUE') 
    plt.title('k-NN DISTANCE WEIGHTED REGRESSION GRAPH') 
    plt.legend(loc='lower right') 
    plt.show 
    
if __name__ == "__main__":
    main() 
